/*
#include <iostream>
#include <cstring>
#include "Batch.h"
using namespace std;

int main()
{
	Batch a(1, 4, 5, 25, 1, 2002, 1, 6, 5, 2022, 80);
	cout << "a" << endl;
	Batch b = a;
	cout << "b" << endl;
	Batch c;
	c = a;
	cout << "c" << endl;

	a.printBatch();
	b.printBatch();
	c.printBatch();

	Batch d(3, 3, 3, 31, 4, 2004, 4, 23, 14, 2006, 70);
	cout<<a.getVolume() << endl;

	return 0;
}*/