//#include <iostream>
//#include <cstring>
//#include "Item.h"
//using namespace std;
//
//int main()
//{
//	cout << "eho" << endl;
//	char name[] = "IVAN";
//	char parameter[] = "kg";
//	
//	Item a(5, name, 80, parameter);
//	Item b = a;
//	Item c;
//	c = a;
//
//	cout << a.getItem_ID() << " " << b.getItem_ID() << " " << c.getItem_ID() << endl;
//	cout << b.getItem_name() << " " << c.getItem_volume() << endl;
//	cout << c.getItem_parameter() << " " << b.getItem_parameter() << " " << a.getItem_parameter() << endl;
//	cout << "//------------------------------------------" << endl;
//
//	a.setItem_ID(8);
//	cout << a.getItem_ID() << " " << b.getItem_ID() << " " << c.getItem_ID() << endl;
//
//	char name2[] = "Borislav";
//	a.setItem_name(name2);
//	cout << a.getItem_name() << " " << b.getItem_name() << " " << c.getItem_name() << endl;
//
//	char param[] = "nervni krizi";
//	b.setItem_parameter(param);
//	cout << a.getItem_parameter() << " " << c.getItem_volume() << " " << b.getItem_parameter() << endl;
//
//	cout << "Prodyljavame" << endl;
//
//	cout << a << endl;
//	cout << b << endl;
//	cout << c << endl;
//
//		
//
//	return 0;
//}