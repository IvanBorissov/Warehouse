#ifndef _SECTION
#define _SECTION

#include "Shelf.h"

struct Section
{
	int ID_Section,shelfCount=4;
	Shelf Shelves[4];
};

#endif
