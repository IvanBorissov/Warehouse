//#include <iostream>
//#include <cstring>
//#include "Supplier.h"
//using namespace std;
//
//int main()
//{
//	char name[] = "Billa";
//	Supplier a(5, name);
//	Supplier b = a;
//	Supplier c;
//	c = a;
//
//	cout << a.getSupplier_ID() << " " << a.getSupplier_name() << endl;
//	cout << b.getSupplier_ID() << " " << b.getSupplier_name() << endl;
//	cout << c.getSupplier_ID() << " " << c.getSupplier_name() << endl;
//	cout << "/------------------------------------" << endl;
//
//	a.setSupplier_ID(7);
//	char name2[] = "Kaufland";
//	a.setSupplier_name(name2);
//
//	char name3[] = "Fantastico";
//	b.setSupplier_name(name3);
//
//	c.setSupplier_ID(19);
//
//	cout << a.getSupplier_ID() << " " << a.getSupplier_name() << endl;
//	cout << b.getSupplier_ID() << " " << b.getSupplier_name() << endl;
//	cout << c.getSupplier_ID() << " " << c.getSupplier_name() << endl;
//
//	return 0;
//}